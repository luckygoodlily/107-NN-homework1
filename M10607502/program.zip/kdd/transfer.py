import requests
import data
import common


def submit(filename='submission.csv'):
    confirm = input('Sure to submit' + filename + '(enter \'YES\') ? ')
    if confirm != 'YES':
        print('Submission canceled. ')
        return
    files = {'files': open(filename, 'rb')}
    d = {
        'user_id': data.SUBMIT_USER_ID,
        'team_token': data.SUBMIT_TOKEN,
        'description': data.SUBMIT_DESC,
        'filename': filename,
    }
    response = requests.post(data.SUBMIT_URL, files=files, data=d)
    print(response.text, '\n')


def download_grid(city, start_time, end_time):
    url = data.DOWNLOAD_URL_GRID + city + '_grid/' \
          + start_time + '/' + end_time + data.DOWNLOAD_URL_TAIL
    path = 'api_' + city + '_grid_' + start_time + '_' + end_time + '.csv'
    common.download(url, path)


def download_aq(city, start_time, end_time):
    url = data.DOWNLOAD_URL_AQ + city + '/' \
          + start_time + '/' + end_time + data.DOWNLOAD_URL_TAIL
    path = 'api_' + city + '_aq_' + start_time + '_' + end_time + '.csv'
    common.download(url, path)


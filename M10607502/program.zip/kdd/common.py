import ast
import numpy as np
import requests


def read_json(file_name):
    file = open(file_name)
    read = ast.literal_eval('\n'.join(file.readlines()))
    file.close()
    return read


def prints(the):
    print(np.divide(np.floor(np.multiply(the, 100)), 100))


def download(url, path):
    print(url)
    response = requests.get(url)
    file = open(path, 'w')
    file.write(response.text)
    file.close()


def dress(pattern: str, replace: str, tos: list):
    results = tos[:]
    for i in range(len(results)):
        results[i] = pattern.replace(replace, results[i])
    return results


def sql_check_table(cursor, table_name):
    return cursor.execute('select count(type) from sqlite_master where name=?', table_name) > 0


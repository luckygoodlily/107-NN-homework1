import tensorflow as tf
import numpy as np
import sqlite3
import preprocessing
import ml
import data
import transfer
import common

print('')

# structure
ac = tf.nn.relu
print('Building...')
features = tf.placeholder(tf.float32, shape=[1, data.INPUTS_COUNT], name='features')
layer1 = tf.layers.dense(features, 1024, activation=ac, name='layer1')
layer2 = tf.layers.dense(layer1, 1024, activation=ac, name='layer2')
layer3 = tf.layers.dense(layer2, 1024, activation=ac, name='layer3')
prediction = tf.layers.dense(layer3, data.OUTPUTS_COUNT, name='prediction')
answers = tf.placeholder(tf.float32, shape=[1, data.OUTPUTS_COUNT], name='answers')
delta = tf.subtract(prediction, answers, name='delta')
loss = tf.losses.mean_squared_error(predictions=prediction, labels=answers)
optimizer = tf.train.AdamOptimizer(0.001)
train = optimizer.minimize(loss, name='train')
structure = {
    'features': features,
    'answers': answers,
    'layer1': layer1,
    'layer2': layer2,
    'layer3': layer3,
    'prediction': prediction,
    'delta': delta,
    'loss': loss,
    'optimizer': optimizer,
    'train': train
}
print('Structure ready. ')

# init
init = tf.global_variables_initializer()
saver = tf.train.Saver()

restore = input('Restore? ')
sess = tf.Session()
if restore == 'n':
    print('Initializing...')
    sess.run(init)
else:
    print('Restoring...')
    saver.restore(sess, data.PATH_CKPT)
print('Session ready. \n')
s = (sess, structure)

over = False
while not over:
    cmd = input('Command: ')
    print('')
    if cmd == 'p':
        preprocessing.statistic()
    elif cmd == 't':
        count = 200
        ml.trains(s=s, start=0, count=count, print_step=1)
        ml.verify(s=s, start=count, count=200, print_step=1)
    elif cmd == 'l':
        count_t = 200
        count_v = 100
        count = count_t + count_v
        for i in range(7):
            print('***** Training Stage', i, 'Start *****')
            print('* Training is underway...')
            ml.trains(s=s, start=i * count, count=count_t, print_step=0)
            print('* Saving session...')
            saver.save(sess, data.PATH_CKPT)
            print('* Verifying...')
            ml.verify(s=s, start=i * count + count_t, count=count_v, print_step=1)
            print('##### Training Stage', i, 'End #####\n')
    elif cmd == 'v':
        ml.verify(s=s, start=16522, count=200, random=False)
    elif cmd == 'g':
        t_date = input('Objective date: ')
        print('')
        t_string = t_date + ' 00:00:00'
        t = data.time_parse(t_string)
        ml.guess(s=s, t=t)
    elif cmd == 'guess':
        t_string = input('Objective time: ')
        print('')
        t = data.time_parse(t_string)
        ml.guess(s=s, t=t)
    elif cmd == 'd':
        year = '2018-'
        hour_start = '-0'
        hour_end = '-23'
        start_month_day = input('From (month-day) : ')
        end_month_day = input('To (month-day) : ')
        start = year + start_month_day + hour_start
        end = year + end_month_day + hour_end
        cities = ['bj', 'ld']
        for city in cities:
            print('Downloading @', city)
            transfer.download_grid(city, start, end)
            print('Downloading grid complete. ')
            transfer.download_aq(city, start, end)
            print('Downloading aq complete. ')
        print('')
    elif cmd == 'download':
        city = input('Download input data at city (short-code) : ')
        start = input('From: ')
        end = input('To: ')
        print('Downloading...')
        transfer.download_grid(city, start, end)
        print('Downloading grid complete. ')
        transfer.download_aq(city, start, end)
        print('Downloading aq complete. ')
        print('')
    elif cmd == 'k':
        preprocessing.kill(depth=2)
    elif cmd == 'submit':
        path = input('Submit prediction file: ')
        print('')
        transfer.submit(path)
    else:
        over = True

sess.close()
print('Session died. ')

import numpy as np
import math
import datetime
from datetime import timedelta
import common


def time_parse(time_string):
    return datetime.datetime.strptime(time_string, TIME_FORMAT)


def wind(wind_direction, wind_speed):
    if wind_direction == 999017:
        return 0., 0.
    else:
        wind_lng = wind_speed * math.cos(wind_direction / 180. * math.pi)
        wind_lat = wind_speed * math.sin(wind_direction / 180. * math.pi)
        return wind_lng, wind_lat


def features_parse(row_input):
    time, temperature, pressure, humidity, wind_direction, wind_speed = row_input
    t = datetime.datetime.strptime(time, TIME_FORMAT)
    wind_lng, wind_lat = wind(wind_direction, wind_speed)
    f_std = [temperature, pressure, humidity, wind_lng, wind_lat]
    f_std = np.divide(np.subtract(f_std, avg_input), s_input)
    features = [f_std[0], f_std[1], f_std[2], f_std[3], f_std[4], t.hour]
    return features


def features_trace(cursor, city, t, grid_name):
    t_last_day = t - timedelta(hours=HOUR_OFFSET)
    f_inside = []
    for i in range(TRACE_COUNT):
        t = t_last_day - timedelta(hours=i * HOUR_STEP)
        row_input = select_input(cursor, city, t, grid_name=grid_name)
        if row_input is None:
            return None
        fi = features_parse(row_input)
        f_inside += fi
    return [f_inside]


def loc2grid(lng, lat, lng0, lat0):
    return round(10 * (21 * (lng - lng0) + (lat - lat0)))


def determine_grid_name(city, lng, lat):
    lng0 = None
    lat0 = None
    if city == CITY_BEIJING:
        lng0 = 115.
        lat0 = 39.
    elif city == CITY_LONDON:
        lng0 = -2.
        lat0 = 50.5
    return city + '_grid_' + repr(loc2grid(lng, lat, lng0, lat0)).zfill(3)


def determine_table_name(t):
    if t >= TIME_CRITICAL:
        return 'inputs_api'
    else:
        return 'inputs'


def select_input(cursor, city, t, lng=115., lat=39., grid_name=None):
    if grid_name is None:
        grid_name = determine_grid_name(city, lng, lat)
    table = determine_table_name(t)
    return cursor.execute(
        'select time, temperature, pressure, humidity, wind_direction, wind_speed from '
        + table + ' where time=? and grid_name=? limit 1',
        (datetime.datetime.strftime(t, TIME_FORMAT), grid_name)
    ).fetchone()


def select_samples(cursor, start, count, random=False):
    random_script = ''
    if random:
        random_script = ' order by random() '
    return cursor.execute(
        'select station_id, time, ' + sql_samples_columns() + ' from samples where ' +
        sql_samples_condition_in_threshold() + random_script + ' limit ?, ?',
        sql_samples_threshold() + (start, count)
    )


def sql_samples_threshold():
    thresholds = ()
    for i in range(OUTPUTS_COUNT):
        threshold = (avg_sample[i] - s_sample[i], avg_sample[i] + s_sample[i])
        thresholds += threshold
    return thresholds


def sql_samples_columns():
    return ', '.join(OUTPUTS_COLUMN_NAMES)


def sql_samples_condition_not_null():
    return ' and '.join(common.dress(' %<>\'\' ', '%', OUTPUTS_COLUMN_NAMES))


def sql_samples_condition_in_threshold():
    return ' and '.join(common.dress(' %>? and %<? ', '%', OUTPUTS_COLUMN_NAMES))


def select_location(cursor, location_id):
    if cache_location == location_id:
        return cache_lng, cache_lat, cache_city
    longitude, latitude, city = cursor.execute('''
    select longitude, latitude, city from locations where location_id=? limit 1
    ''', (location_id,)).fetchone()
    lng = round(longitude, 1)
    lat = round(latitude, 1)
    return lng, lat, city


def determine_city(station_id):
    if station_id is None or station_id == '':
        return None
    if station_id.isupper():
        return CITY_LONDON
    else:
        return CITY_BEIJING


HOUR_STEP = 1
HOUR_OFFSET = 72
HOUR_STEAL = 1
TRACE_COUNT = 1
INPUTS_COUNT = TRACE_COUNT * 6
OUTPUTS_COLUMN_NAMES = ['pm25', 'pm10', 'o3', 'no2', 'co', 'so2']
# OUTPUTS_COUNT = 6
OUTPUTS_COUNT = len(OUTPUTS_COLUMN_NAMES)
TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
TIME_CRITICAL = datetime.datetime.combine(datetime.date(2018, 4, 1), datetime.time(0, 0, 0))
CITY_BEIJING = 'beijing'
CITY_LONDON = 'london'
PATH_DB = 'kdd.db'
PATH_CKPT = 'ckpt/kdd.ckpt'
PATH_INFO = 'kdd.info'
PATH_SUBMIT_SAMPLE = 'sample_submission.csv'
PATH_SUBMIT_CSV = 'submission.csv'
PATH_DOWNLOADED_GRID = 'api_grid_'
PATH_DOWNLOADED_AQ = 'api_aq_'
DOWNLOAD_URL_GRID = 'https://biendata.com/competition/meteorology/'
DOWNLOAD_URL_AQ = 'https://biendata.com/competition/airquality/'
DOWNLOAD_URL_TAIL = '/2k0d1d8'
DOWNLOAD_CITY_BEIJING = 'bj'
DOWNLOAD_CITY_LONDON = 'ln'
SUBMIT_USER_ID = 'veringsek' # 'EE610'
SUBMIT_DESC = 'EE610'
SUBMIT_TOKEN = '1c555835c3f5f05122d653ed3f8c97cae49557d5baed6df7c1d3086ab957ba4d'
SUBMIT_URL = 'https://biendata.com/competition/kdd_2018_submit/'

# load info
info = common.read_json(PATH_INFO)
avg_sample = info['sample']['average']
s_sample = info['sample']['s']
avg_input = info['input']['average']
s_input = info['input']['s']

# cache
cache_location = None
cache_lng = None
cache_lat = None
cache_city = None

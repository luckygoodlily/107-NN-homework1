import sqlite3
import numpy as np
import data
import common


def statistic(count=1000):
    conn = sqlite3.connect('kdd.db')
    cursor = conn.cursor()

    # sample
    rows = cursor.execute(
        'select ' + data.sql_samples_columns() + ' from samples where ' +
        data.sql_samples_condition_not_null() + ' order by random() limit ?',
        (count, )
    ).fetchall()
    avg_sample = np.zeros(data.OUTPUTS_COUNT, dtype=np.float)
    for row in rows:
        avg_sample = np.add(avg_sample, list(row))
    avg_sample = np.divide(avg_sample, count)
    s_sample = np.zeros(data.OUTPUTS_COUNT, dtype=np.float)
    for row in rows:
        s_sample = np.add(s_sample, np.square(np.subtract(list(row), avg_sample)))
    s_sample = np.sqrt(np.divide(s_sample, count - 1))

    # input
    rows = cursor.execute('''
    select temperature, pressure, humidity, wind_direction, wind_speed from inputs 
    where temperature<>'' and pressure<>'' and humidity<>'' 
    and wind_direction<>'' and wind_speed<>''
    order by random() limit ?
    ''', (count, )).fetchall()
    avg_input = np.zeros(5, dtype=np.float)
    for row in rows:
        wind_lng, wind_lat = data.wind(row[3], row[4])
        r = row[:3] + (wind_lng, wind_lat)
        avg_input = np.add(avg_input, list(r))
    avg_input = np.divide(avg_input, count)
    s_input = np.zeros(5, dtype=np.float)
    for row in rows:
        s_input = np.add(s_input, np.square(np.subtract(list(row), avg_input)))
    s_input = np.sqrt(np.divide(s_input, count - 1))

    info = {
        'sample': {
            'average': (avg_sample.tolist()),
            's': (s_sample.tolist())
        },
        'input': {
            'average': (avg_input.tolist()),
            's': (s_input.tolist())
        }
    }
    file = open(data.PATH_INFO, 'w')
    file.write(repr(info))
    print(repr(info), '\n')
    file.close()


def kill(depth=1):
    conn = sqlite3.connect(data.PATH_DB)
    cursor = conn.cursor()
    keeps = set([])
    rows_location = cursor.execute('select * from locations')
    print('Scanning locations...')
    for row_location in rows_location:
        location_id, longitude, latitude, city = row_location
        lng = round(longitude, 1)
        lat = round(latitude, 1)
        for x in range(depth):
            _lng = lng - x * 0.1
            for y in range(depth):
                keeps.add(data.determine_grid_name(city, _lng, lat - y * 0.1))
                keeps.add(data.determine_grid_name(city, _lng, lat + y * 0.1))
            _lng = lng + x * 0.1
            for y in range(depth):
                keeps.add(data.determine_grid_name(city, _lng, lat - y * 0.1))
                keeps.add(data.determine_grid_name(city, _lng, lat + y * 0.1))
    print()
    print('Removing...')
    print('Existing inputs count: ',
          cursor.execute('select count(grid_name) from inputs').fetchone())
    keeps_string = '\'' + '\',\''.join(keeps) + '\''
    cursor.execute('delete from inputs where grid_name not in (' + keeps_string + ')')
    print('Remaining inputs count: ',
          cursor.execute('select count(grid_name) from inputs').fetchone())
    print('Removing complete. ')
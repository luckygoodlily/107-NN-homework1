import pandas as pd
import numpy as np

fullData = pd.read_csv('C:/Users/biorb/KDD/429l.csv')
a = fullData.set_index('station_id')

fullData = fullData.set_index('time')

# print(fullData.columns) # 顯示所有的列名稱
# print(fullData.head(10)) #顯示數據框的前10條記錄
# print(fullData.describe()) #你可以使用describe()函數查看數值域的概要
# print(fullData.isnull().any())#返回True或False，True意味着有缺失值而False相反

station_list = fullData.drop_duplicates(['station_id'])

station_list = np.array(station_list.station_id)

cols = ['time','PM25_Concentration', 'PM10_Concentration']
for stat in station_list:
    locals()['%s'%(stat)] =  a.loc[stat, cols]
    locals()['%s'%(stat)] =  locals()['%s'%(stat)].set_index('time')
    locals()['%s'%(stat)].rename(columns={'PM25_Concentration': str(stat)+'_PM25','PM10_Concentration': str(stat)+'_PM10'}, inplace=True)
    locals()['%s'%(stat)] = locals()['%s'%(stat)].fillna(locals()['%s'%(stat)].ffill())
    locals()['%s'%(stat)] = locals()['%s'%(stat)].fillna(0)
    locals()['%s'%(stat)] = locals()['%s'%(stat)].reset_index(drop=True)
alld = pd.concat([CD1,BL0,GR4,MY7,HV1,GN3,GR9,LW2,GN0,KF1,CD9,ST5,TH4],axis=1, ignore_index=True)


print(alld)
cols = alld.columns.values

alld = alld.fillna(alld.ffill())
#
alld = alld.fillna(alld.bfill())

# alld = alld.dropna(axis=1)
alld[cols] = alld[cols].fillna(0)

print(alld.isnull().any())#返回True或False，True意味着有缺失值而False相反
#
alld.to_csv("428LLL.csv")

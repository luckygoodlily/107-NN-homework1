import pandas as pd
import numpy as np

fullData = pd.read_csv('C:/Users/biorb/KDD/429b.csv')
a = fullData.set_index('station_id')
fullData = fullData.set_index('time')

# print(fullData.columns) # 顯示所有的列名稱
# print(fullData.head(10)) #顯示數據框的前10條記錄
# print(fullData.describe()) #你可以使用describe()函數查看數值域的概要
# print(fullData.isnull().any())#返回True或False，True意味着有缺失值而False相反

station_list = fullData.drop_duplicates(['station_id'])
station_list = np.array(station_list.station_id)
print(station_list)
cols = ['time','PM25_Concentration', 'PM10_Concentration', 'O3_Concentration']
for stat in station_list:

    locals()['%s'%(stat)] =  a.loc[stat, cols]
    locals()['%s'%(stat)] =  locals()['%s'%(stat)].set_index('time')
    locals()['%s'%(stat)].rename(columns={'PM25_Concentration': str(stat)+'_PM2.5','PM10_Concentration': str(stat)+'_PM10'
    ,'O3_Concentration': str(stat)+'_O3'}, inplace=True)

alld = pd.concat([dongsi_aq
,tiantan_aq,guanyuan_aq,wanshouxigong_aq,aotizhongxin_aq,nongzhanguan_aq,wanliu_aq,beibuxinqu_aq
 ,zhiwuyuan_aq,fengtaihuayuan_aq,yungang_aq,gucheng_aq,fangshan_aq,
 daxing_aq,yizhuang_aq,tongzhou_aq,shunyi_aq,pingchang_aq,mentougou_aq,pinggu_aq,huairou_aq,miyun_aq,
 yanqin_aq,dingling_aq,badaling_aq,miyunshuiku_aq,donggaocun_aq,
 yongledian_aq,yufa_aq,liulihe_aq,qianmen_aq,yongdingmennei_aq,xizhimenbei_aq,nansanhuan_aq,dongsihuan_aq
 ],axis=1)

# print(alld)
cols = np.array(alld.columns.values)

alld[cols] = alld[cols].fillna(alld[cols].ffill())

# alld[cols] = alld[cols].fillna(alld[cols].median())

alld[cols] = alld[cols].fillna(0)

print(alld.isnull().any())#返回True或False，True意味着有缺失值而False相反
#
alld.to_csv("428BBB.csv")
